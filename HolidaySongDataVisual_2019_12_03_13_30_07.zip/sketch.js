let table;
let img;
let mode;
let names = [];
let energyAtt = [];
let circRankE = [];
let circRankEAtt = [];
let danceAtt = [];
let circRankD = [];
let circRankDAtt = [];
let tempoAtt = [];
let circRankT = [];
let circRankTAtt = [];

function preload() {

  img = loadImage("snowflake.png");
  table = loadTable("Holiday_Songs_Spotify.csv", 'csv', 'header');

}

function setup() {
  createCanvas(550, 550);
  background(255);
  mode = "o";

  img.resize(70, 0);

  for (let r = 0; r < 16; r++) {
    let currName = table.getString(r, 18);
    names[r] = currName;
  }

  for (let r = 0; r < 16; r++) {
    let currEnergy = table.getString(r, 3);
    energyAtt[r] = currEnergy;
  }

  for (let r = 0; r < 16; r++) {
    let currDance = table.getString(r, 2);
    danceAtt[r] = currDance;
  }

  for (let r = 0; r < 16; r++) {
    let currTempo = table.getString(r, 12);
    tempoAtt[r] = currTempo;
  }
}

function draw() {
  checkMode();
  //print("checked");

  fill(0);
  textSize(18);
  //text("x: " + mouseX + ", y: " + mouseY, 370, 490);

  image(img, 5, 5);
  fill(0);
  textSize(15);
  text("Instructions", 5, 80);

  if (mouseX < 85 && mouseY < 85) {
    fill(255);
    stroke(150);
    rect(mouseX, mouseY, 180, 65);
    noStroke();
    fill(150);
    textSize(15);
    text("Press 'o' for original\nPress 'e' for energy\nPress 'd' for danceability", mouseX + 7, mouseY + 20);
    
    //\nPress 't' for tempo
  }

}

function keyTyped() {
  if (key === 'o') {
    mode = "o";
  } else if (key === 'e') {
    mode = "e";
    //print("e pressed");
  } else if (key === 'd') {
    mode = "d";
  } else if (key === 't') {
    //mode = "t";
  }
}

function checkMode() {
  //print("checking");

  if (mode === "o") {
    original();
    //print("original");
  } else if (mode === "e") {
    energy();
    //print("energy");
  } else if (mode === "d") {
    danceability();
    //print("danceability");
  } else if (mode === "t") {
    tempo();
    //print("tempo");
  }
}

function original() {
  background(255);

  fill(31, 135, 73);
  textSize(30);
  textAlign(CENTER);
  text("O\nR\nI\nG\nI\nN\nA\nL", 41, 130);
  textAlign(LEFT);

  fill(204, 37, 53);
  textSize(30);
  text("Song List:", 115, 30);

  var yName = 60;

  for (let r = 0; r < 16; r++) {
    fill(120);
    textSize(18);
    text(names[r], 115, yName);
    yName += 22;
  }
}

function energy() {
  background(255);

  fill(31, 135, 73);
  textSize(30);
  textAlign(CENTER);
  text("E\nN\nE\nR\nG\nY", 41, 130);
  textAlign(LEFT);

  fill(204, 37, 53);
  textSize(30);
  text("Ranked Songs:", 115, 30);

  let circX = 150;
  let circY = 80;
  let currHighEnergy;

  for (let r = 0; r < 16; r++) {
    fill(120);
    textSize(18);

    if (r === 0) {
      currHighEnergy = findHighest(energyAtt, 1);
    } else {
      currHighEnergy = findHighest(energyAtt, currHighEnergy);
    }

    let idx = energyAtt.indexOf(currHighEnergy);
    circRankE[r] = names[idx];
    circRankEAtt[r] = currHighEnergy;

    fill(163, 178, 193);
    circle(circX, circY, currHighEnergy * 100);
    textSize(10);

    circX += 100;
    if (circX > 500) {
      circX = 150;
      circY += 100;
    }
  }
  
  if (mouseX > 100 && mouseX < 200 && mouseY > 30 && mouseY < 130) {
    rolloverE(0);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 30 && mouseY < 130) {
    rolloverE(1);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 30 && mouseY < 130) {
    rolloverE(2);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 30 && mouseY < 130) {
    rolloverE(3);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 130 && mouseY < 230) {
    rolloverE(4);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 130 && mouseY < 230) {
    rolloverE(5);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 130 && mouseY < 230) {
    rolloverE(6);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 130 && mouseY < 230) {
    rolloverE(7);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 230 && mouseY < 330) {
    rolloverE(8);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 230 && mouseY < 330) {
    rolloverE(9);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 230 && mouseY < 330) {
    rolloverE(10);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 230 && mouseY < 330) {
    rolloverE(11);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 330 && mouseY < 430) {
    rolloverE(12);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 330 && mouseY < 430) {
    rolloverE(13);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 330 && mouseY < 430) {
    rolloverE(14);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 330 && mouseY < 430) {
    rolloverE(15);
  }

}

function danceability() {
  background(255);

  fill(31, 135, 73);
  textSize(25);
  textAlign(CENTER);
  text("D\nA\nN\nC\nE\nA\nB\nI\nL\nI\nT\nY", 41, 120);
  textAlign(LEFT);

  fill(204, 37, 53);
  textSize(30);
  text("Ranked Songs:", 115, 30);

  let circX = 150;
  let circY = 80;
  let currHighDance;

  for (let r = 0; r < 16; r++) {
    fill(120);
    textSize(18);

    if (r === 0) {
      currHighDance = findHighest(danceAtt, 1);
    } else {
      currHighDance = findHighest(danceAtt, currHighDance);
    }

    let idx = danceAtt.indexOf(currHighDance);
    circRankD[r] = names[idx];
    circRankDAtt[r] = currHighDance;

    fill(163, 178, 193);
    circle(circX, circY, currHighDance * 100);
    textSize(10);

    circX += 100;
    if (circX > 500) {
      circX = 150;
      circY += 100;
    }
  }

  if (mouseX > 100 && mouseX < 200 && mouseY > 30 && mouseY < 130) {
    rolloverD(0);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 30 && mouseY < 130) {
    rolloverD(1);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 30 && mouseY < 130) {
    rolloverD(2);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 30 && mouseY < 130) {
    rolloverD(3);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 130 && mouseY < 230) {
    rolloverD(4);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 130 && mouseY < 230) {
    rolloverD(5);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 130 && mouseY < 230) {
    rolloverD(6);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 130 && mouseY < 230) {
    rolloverD(7);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 230 && mouseY < 330) {
    rolloverD(8);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 230 && mouseY < 330) {
    rolloverD(9);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 230 && mouseY < 330) {
    rolloverD(10);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 230 && mouseY < 330) {
    rolloverD(11);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 330 && mouseY < 430) {
    rolloverD(12);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 330 && mouseY < 430) {
    rolloverD(13);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 330 && mouseY < 430) {
    rolloverD(14);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 330 && mouseY < 430) {
    rolloverD(15);
  }
  
}

function tempo() {
  background(255);
  
  //print("start tempo");

  fill(31, 135, 73);
  textSize(30);
  textAlign(CENTER);
  text("T\nE\nM\nP\nO", 41, 130);
  textAlign(LEFT);

  fill(204, 37, 53);
  textSize(30);
  text("Ranked Songs:", 115, 30);

  let circX = 150;
  let circY = 80;
  let currHighTempo;

  //print("Start");
  
  for (let r = 0; r < 16; r++) {
    fill(120);
    textSize(18);

    if (r === 0) {
      currHighTempo = findHighest(tempoAtt, 300);
      //print(currHighTempo);
    } else {
      currHighTempo = findHighest(tempoAtt, currHighTempo);
    }
    
    //print(currHighTempo);

    let idx = tempoAtt.indexOf(currHighTempo);
    circRankT[r] = names[idx];
    circRankTAtt[r] = currHighTempo;

    fill(163, 178, 193);
    circle(circX, circY, currHighTempo/200 * 100);
    textSize(10);

    circX += 100;
    if (circX > 500) {
      circX = 150;
      circY += 100;
    }
  }
  
  if (mouseX > 100 && mouseX < 200 && mouseY > 30 && mouseY < 130) {
    rolloverT(0);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 30 && mouseY < 130) {
    rolloverT(1);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 30 && mouseY < 130) {
    rolloverT(2);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 30 && mouseY < 130) {
    rolloverT(3);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 130 && mouseY < 230) {
    rolloverT(4);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 130 && mouseY < 230) {
    rolloverT(5);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 130 && mouseY < 230) {
    rolloverT(6);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 130 && mouseY < 230) {
    rolloverT(7);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 230 && mouseY < 330) {
    rolloverT(8);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 230 && mouseY < 330) {
    rolloverT(9);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 230 && mouseY < 330) {
    rolloverT(10);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 230 && mouseY < 330) {
    rolloverT(11);
  } else if (mouseX > 100 && mouseX < 200 && mouseY > 330 && mouseY < 430) {
    rolloverT(12);
  } else if (mouseX > 200 && mouseX < 300 && mouseY > 330 && mouseY < 430) {
    rolloverT(13);
  } else if (mouseX > 300 && mouseX < 400 && mouseY > 330 && mouseY < 430) {
    rolloverT(14);
  } else if (mouseX > 400 && mouseX < 500 && mouseY > 330 && mouseY < 430) {
    rolloverT(15);
  }

}

function findHighest(arr, max) {
  let high = 0;

  for (let r = 0; r < 16; r++) {
    //print("Num at " + r + ": " + arr[r]);
    //print("Curr high: " + high);
    //print("Max: " + max);
    if (arr[r] > high && arr[r] < max) {
      high = arr[r];
      //print("New high: " + high);
    }
  }
  
  return high;
}

function rolloverE(num) {
  let str = circRankE[num] + " (" + circRankEAtt[num] + ")";
  let sWidth = textWidth(str) + 115;
  fill(255);
  stroke(150);
  rect(mouseX, mouseY, sWidth, 30);
  noStroke();
  fill(150);
  textSize(15);
  text(str, mouseX + 7, mouseY + 20);
}

function rolloverD(num) {
  let str = circRankD[num] + " (" + circRankDAtt[num] + ")";
  let sWidth = textWidth(str) + 115;
  fill(255);
  stroke(150);
  rect(mouseX, mouseY, sWidth, 30);
  noStroke();
  fill(150);
  textSize(15);
  text(str, mouseX + 7, mouseY + 20);
}

function rolloverT(num) {
  let str = circRankT[num] + " (" + circRankTAtt[num] + ")";
  let sWidth = textWidth(str) + 115;
  fill(255);
  stroke(150);
  rect(mouseX, mouseY, sWidth, 30);
  noStroke();
  fill(150);
  textSize(15);
  text(str, mouseX + 7, mouseY + 20);
}